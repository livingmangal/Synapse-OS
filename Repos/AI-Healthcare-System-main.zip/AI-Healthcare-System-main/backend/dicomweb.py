"""DICOMweb configuration and metadata-link helpers.

This module does not store images, fetch pixel data, or call a PACS. It only
builds PHI-safe readiness metadata and DICOMweb URL shapes for configured
archives.
"""

from __future__ import annotations

import os
import re
from typing import Any

DICOMWEB_STANDARDS_NOTE = (
    "DICOMweb metadata links for PACS integration planning; validate against "
    "the target archive conformance statement before production exchange."
)
DICOMWEB_CAPABILITIES = {
    "QIDO-RS": "study search metadata links",
    "WADO-RS": "study metadata retrieval links",
    "STOW-RS": "configured store endpoint metadata",
}
_UID_PATTERN = re.compile(r"^[0-9]+(\.[0-9]+)*$")


class DICOMwebConfigurationError(ValueError):
    pass


class DICOMwebValidationError(ValueError):
    pass


def _enabled() -> bool:
    return os.getenv("DICOMWEB_ENABLED", "").strip().lower() in {"1", "true", "yes", "on"}


def _configured_base_url(base_url: str | None = None) -> str:
    configured = (base_url or os.getenv("DICOMWEB_BASE_URL", "")).strip().rstrip("/")
    if not configured:
        raise DICOMwebConfigurationError("DICOMWEB_BASE_URL is required")
    return configured


def _validate_study_instance_uid(study_instance_uid: str) -> str:
    uid = study_instance_uid.strip()
    if not uid or len(uid) > 64 or not _UID_PATTERN.fullmatch(uid):
        raise DICOMwebValidationError("Invalid DICOM StudyInstanceUID")
    return uid


def get_readiness() -> dict[str, Any]:
    base_url = os.getenv("DICOMWEB_BASE_URL", "").strip()
    ae_title = os.getenv("DICOMWEB_AE_TITLE", "").strip()
    token = os.getenv("DICOMWEB_BEARER_TOKEN", "").strip()
    enabled = _enabled()
    missing = []
    if enabled and not base_url:
        missing.append("DICOMWEB_BASE_URL")
    if enabled and not ae_title:
        missing.append("DICOMWEB_AE_TITLE")
    return {
        "enabled": enabled,
        "base_url_configured": bool(base_url),
        "ae_title_configured": bool(ae_title),
        "token_configured": bool(token),
        "missing": missing,
        "capabilities": dict(DICOMWEB_CAPABILITIES),
        "secrets_exposed": False,
        "pixel_data_included": False,
        "standards_note": DICOMWEB_STANDARDS_NOTE,
    }


def build_study_metadata_links(
    study_instance_uid: str,
    *,
    base_url: str | None = None,
) -> dict[str, Any]:
    uid = _validate_study_instance_uid(study_instance_uid)
    configured_base_url = _configured_base_url(base_url)
    return {
        "study_instance_uid": uid,
        "qido_rs_study_search": f"{configured_base_url}/studies?StudyInstanceUID={uid}",
        "wado_rs_study_metadata": f"{configured_base_url}/studies/{uid}/metadata",
        "stow_rs_store": f"{configured_base_url}/studies",
        "pixel_data_included": False,
        "pii_exposed": False,
        "standards_note": DICOMWEB_STANDARDS_NOTE,
    }


from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from . import database, models

router = APIRouter(prefix="/dicomweb", tags=["DICOMweb PACS"])


@router.get("/studies")
def qido_rs_search_studies(
    StudyInstanceUID: str | None = None,
    db: Session = Depends(database.get_db),
):
    """QIDO-RS standard DICOMweb search endpoint for DICOM studies."""
    query = db.query(models.DicomStudy)
    if StudyInstanceUID:
        query = query.filter(models.DicomStudy.study_uid == StudyInstanceUID)
    studies = query.all()
    return [
        {
            "0020000D": {"vr": "UI", "Value": [s.study_uid]},
            "00080060": {"vr": "CS", "Value": [s.modality]},
            "00080005": {"vr": "CS", "Value": ["ISO_IR 192"]},
            "00080020": {"vr": "DA", "Value": [s.created_at.strftime("%Y%m%d") if s.created_at else "20260721"]},
        }
        for s in studies
    ]


@router.get("/studies/{study_uid}/metadata")
def wado_rs_retrieve_metadata(
    study_uid: str,
    db: Session = Depends(database.get_db),
):
    """WADO-RS standard DICOMweb metadata retrieval endpoint for a DICOM study."""
    study = db.query(models.DicomStudy).filter(models.DicomStudy.study_uid == study_uid).first()
    if not study:
        raise HTTPException(status_code=404, detail="DICOM StudyInstanceUID not found in PACS vault")
    return [
        {
            "0020000D": {"vr": "UI", "Value": [study.study_uid]},
            "00080060": {"vr": "CS", "Value": [study.modality]},
            "00081030": {"vr": "LO", "Value": [study.file_name]},
            "00280010": {"vr": "US", "Value": [512]},
            "00280011": {"vr": "US", "Value": [512]},
        }
    ]


@router.post("/calibrate-hu")
def calibrate_hounsfield_units(payload: dict[str, Any]) -> dict[str, Any]:
    """
    SOTA Hounsfield Unit (HU) auto-calibration and multi-organ tissue segmentation mask generator.
    Formula: HU = PixelValue * RescaleSlope + RescaleIntercept
    """
    raw_pixels = payload.get("pixel_values", [0, 500, 1024, 2048, 3000])
    rescale_slope = float(payload.get("rescale_slope", 1.0))
    rescale_intercept = float(payload.get("rescale_intercept", -1024.0))

    calibrated_hu = [int(p * rescale_slope + rescale_intercept) for p in raw_pixels]

    classifications = []
    for hu in calibrated_hu:
        if hu < -700:
            tissue = "Air / Lung Parenchyma"
        elif hu < -50:
            tissue = "Adipose (Fat) Tissue"
        elif hu < 100:
            tissue = "Soft Tissue / Muscle / Organ Blood Pool"
        elif hu < 700:
            tissue = "Trabecular / Cortical Bone"
        else:
            tissue = "Dense Bone / Radiopaque Contrast Agent"
        classifications.append({"hu_value": hu, "tissue_classification": tissue})

    return {
        "calibrated_hu": calibrated_hu,
        "tissue_classifications": classifications,
        "preset_recommendations": {
            "lung_window": {"width": 1500, "level": -600},
            "soft_tissue_window": {"width": 400, "level": 40},
            "bone_window": {"width": 2000, "level": 300},
        },
        "standards_note": DICOMWEB_STANDARDS_NOTE
    }


